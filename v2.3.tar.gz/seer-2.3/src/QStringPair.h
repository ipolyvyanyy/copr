#pragma once

#include <QtCore/QString>
#include <QtCore/QPair>

typedef QPair<QString,QString> QStringPair;

