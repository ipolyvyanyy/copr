Contributions are welcomed as a Pull Request. Features and bug reports as GitHub issues or a simple email to epasveer@att.net.
